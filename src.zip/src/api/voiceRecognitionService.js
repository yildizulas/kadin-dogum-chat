export const startVoiceRecognition = (setText) => {
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;
  
    if (!SpeechRecognition) {
      alert("Tarayıcınız ses tanımayı desteklemiyor.");
      return;
    }
  
    const recognition = new SpeechRecognition();
    recognition.lang = "tr-TR"; // Türkçe desteği
    recognition.continuous = false;
    recognition.interimResults = false;
  
    recognition.onstart = () => {
      console.log("Ses tanıma başladı...");
    };
  
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setText(transcript);
      console.log("Algılanan metin:", transcript);
    };
  
    recognition.onerror = (event) => {
      console.error("Hata oluştu:", event.error);
    };
  
    recognition.onend = () => {
      console.log("Ses tanıma durduruldu.");
    };
  
    recognition.start();
  };