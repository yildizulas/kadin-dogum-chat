import axios from "axios";

const API_KEY = process.env.REACT_APP_GOOGLE_TTS_KEY;
const API_URL = `https://texttospeech.googleapis.com/v1/text:synthesize?key=${API_KEY}`;

let audio = null;
let setIsSpeakingGlobal = null; // Durum değişimini takip edebilmek için global değişken

export const textToSpeech = async (text, setIsSpeaking) => {
  try {
    if (audio && !audio.paused) {
      stopSpeech();
      return;
    }

    setIsSpeakingGlobal = setIsSpeaking; // setState fonksiyonunu global değişkene ata
    setIsSpeaking(true); // Butonu "Durdur" yap

    const requestData = {
      input: { text: text },
      voice: {
        languageCode: "tr-TR",
        name: "tr-TR-Wavenet-D",
        ssmlGender: "FEMALE",
      },
      audioConfig: { audioEncoding: "MP3" },
    };

    const response = await axios.post(
      API_URL,
      requestData,
      {
        headers: { "Content-Type": "application/json" },
      }
    );

    if (!response.data.audioContent) {
      throw new Error("Ses verisi bulunamadı!");
    }

    const audioContent = response.data.audioContent;
    const audioBlob = new Blob(
      [
        Uint8Array.from(atob(audioContent), (c) =>
          c.charCodeAt(0)
        ),
      ],
      { type: "audio/mp3" }
    );
    const audioUrl = URL.createObjectURL(audioBlob);

    audio = new Audio(audioUrl);
    audio.play();

    // Sesli yanıt bittiğinde butonu tekrar "Dinle" olarak güncelle
    audio.onended = () => {
      console.log("Sesli yanıt tamamlandı.");
      setIsSpeaking(false); // Butonu "Dinle" yap
      audio = null;
    };
  } catch (error) {
    console.error(
      "Google TTS API Hatası:",
      error.response?.data || error.message
    );
  }
};

// **Konuşmayı durdur**
export const stopSpeech = () => {
  if (audio) {
    audio.pause();
    audio.currentTime = 0;
    audio = null;
    if (setIsSpeakingGlobal) {
      setIsSpeakingGlobal(false); // Butonu tekrar "Dinle" yap
    }
  }
};
