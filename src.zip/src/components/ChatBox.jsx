import React, { useState } from "react";
import {
  textToSpeech,
  stopSpeech,
} from "../api/textToSpeechService";
import { startVoiceRecognition } from "../api/voiceRecognitionService"; // Sesle yazma fonksiyonu

const ChatBox = ({ messages, sendMessage }) => {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [inputText, setInputText] = useState("");
  const [isListening, setIsListening] = useState(false); // Sesle yazma durumu

  // GPT'nin konuşmasını başlat/durdur
  const handleSpeech = (text) => {
    if (isSpeaking) {
      stopSpeech();
      setIsSpeaking(false);
    } else {
      textToSpeech(text, setIsSpeaking);
    }
  };

  // Kullanıcının mesajını gönderme
  const handleSend = () => {
    if (inputText.trim() !== "") {
      sendMessage(inputText);
      setInputText(""); // Mesaj gönderildikten sonra input'u temizle
    }
  };

  // **Sesle Yaz Butonu için Konuşma Tanıma Başlat**
  const handleVoiceInput = () => {
    setIsListening(true); // Butonun durumu değişsin

    startVoiceRecognition()
      .then((result) => {
        setInputText(result); // Kullanıcının söylediği metni input'a koy
        setIsListening(false);
      })
      .catch(() => {
        setIsListening(false);
      });
  };

  return (
    <div className="chat-box">
      {messages.map((msg, index) => (
        <div
          key={index}
          className={`chat-message ${msg.role}`}
        >
          <p>{msg.content}</p>
          {msg.role === "assistant" && (
            <button
              className="read-aloud-button"
              onClick={() => handleSpeech(msg.content)}
            >
              {isSpeaking ? "⏹️ Durdur" : "🔊 Dinle"}
            </button>
          )}
        </div>
      ))}

      {/* Kullanıcı mesaj giriş alanı */}
      <div className="input-container">
        <textarea
          className="textarea"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Sorunuzu buraya yazın..."
        />

        {/* Butonları Yan Yana Getiriyoruz */}
        <div className="button-group">
          <button
            className="voice-button"
            onClick={handleVoiceInput}
          >
            🎤 {isListening ? "Dinleniyor..." : "Sesle Yaz"}
          </button>
          <button
            className="send-button"
            onClick={handleSend}
          >
            Gönder
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatBox;
