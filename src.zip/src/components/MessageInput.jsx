import React, { useState } from "react";

const MessageInput = ({ onSendMessage }) => {
  const [message, setMessage] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (message.trim() === "") return;
    onSendMessage(message);
    setMessage("");
  };

  const handleVoiceInput = () => {
    const recognition =
      new window.webkitSpeechRecognition();
    recognition.lang = "tr-TR";
    recognition.start();

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setMessage(transcript);
    };
  };

  return (
    <form onSubmit={handleSubmit} className="message-form">
      <textarea
        className="textarea"
        placeholder="Sorunuzu buraya yazın veya mikrofonu kullanın..."
        value={message}
        onChange={(e) => setMessage(e.target.value)}
      />
      <button
        type="button"
        className="voice-button"
        onClick={handleVoiceInput}
      >
        🎤
      </button>
      <button type="submit" className="send-button">
        Gönder
      </button>
    </form>
  );
};

export default MessageInput;
