import React from "react";
import ChatPage from "./pages/ChatPage";

function App() {
  return (
    <div>
      <ChatPage />
    </div>
  );
}

export default App;
