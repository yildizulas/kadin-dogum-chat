import React, { useState } from "react";
import Header from "../components/Header";
import ChatBox from "../components/ChatBox";
import { askGPT } from "../api/gptService";
import RecommendedQuestions from "../components/RecommendedQuestions";

const ChatPage = () => {
  const [messages, setMessages] = useState([]);

  // Kullanıcının mesajını alıp, GPT'ye sorma fonksiyonu
  const handleSendMessage = async (message) => {
    if (!message.trim()) return; // Boş mesaj gönderilmesini engelle
    const userMessage = { role: "user", content: message };

    setMessages((prevMessages) => [
      ...prevMessages,
      userMessage,
    ]);

    try {
      const response = await askGPT(message);
      const botMessage = {
        role: "assistant",
        content: response,
      };

      setMessages((prevMessages) => [
        ...prevMessages,
        botMessage,
      ]);
    } catch (error) {
      console.error("GPT API hatası:", error);
    }
  };

  return (
    <div className="container">
      <Header />
      <ChatBox
        messages={messages}
        sendMessage={handleSendMessage}
      />
      <RecommendedQuestions
        onSelectQuestion={handleSendMessage}
      />
    </div>
  );
};

export default ChatPage;
